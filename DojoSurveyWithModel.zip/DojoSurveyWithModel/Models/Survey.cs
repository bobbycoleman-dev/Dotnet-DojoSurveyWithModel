#pragma warning disable CS8618
namespace DojoSurveyWithModel.Models;

public class Survey
{
    public string Name { get; set; }
    public string DojoLocation { get; set; }
    public string FavoriteLanguage { get; set; }
    public string? Comment { get; set; }

}